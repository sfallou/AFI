echo "0" > state
